# -*- coding: utf-8 -*-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 חיסכון ועמלות", callback_data="menu_savings")],
        [InlineKeyboardButton(text="🏠 ניהול כלכלת הבית", callback_data="menu_household")],
        [InlineKeyboardButton(text="📚 אקדמיה  ללמוד", callback_data="menu_academy")],
        [InlineKeyboardButton(text="👥 קהילה וכלים", callback_data="menu_community")],
        [InlineKeyboardButton(text="🎁 מתנה יומית", callback_data="gift")],
        [InlineKeyboardButton(text="👤 פרופיל אישי", callback_data="profile")],
        [InlineKeyboardButton(text="ℹ️ עזרה", callback_data="help")],
        [InlineKeyboardButton(text="📱 מחשבון ויזואלי", web_app=WebAppInfo(url="https://taxfreeworldbot-production.up.railway.app/landing/miniapp.html"))],
        [InlineKeyboardButton(text="🌐 קהילות", callback_data="communities")],
        [InlineKeyboardButton(text="🗺️ מפת דרכים", callback_data="roadmap")],
        [InlineKeyboardButton(text="❤️ תרומה לפרויקט", callback_data="donate")],
        [InlineKeyboardButton(text="📬 צור קשר", callback_data="contact")],
    ])

def back_to_main():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 חזרה לתפריט הראשי", callback_data="start")]
    ])

def savings_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💸 מחשבון עמלות", callback_data="compare_prompt")],
        [InlineKeyboardButton(text="📊 תרחישים מהירים", callback_data="presets")],
        [InlineKeyboardButton(text="👛 איך פותחים ארנק", callback_data="wallet")],
        [InlineKeyboardButton(text="🔍 למה TON?", callback_data="why")],
        [InlineKeyboardButton(text="🤖 שאל שאלה", callback_data="ask")],
        [InlineKeyboardButton(text="📝 דיווח תקלה", callback_data="feedback")],
        [InlineKeyboardButton(text="🔙 חזרה", callback_data="start")],
    ])

def household_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 מחשבון תקציב", callback_data="budget_prompt")],
        [InlineKeyboardButton(text="👤 הפרופיל שלי", callback_data="profile")],
        [InlineKeyboardButton(text="➕ הוסף הוצאה", callback_data="addexpense")],
        [InlineKeyboardButton(text="📋 ההוצאות שלי", callback_data="expenses")],
        [InlineKeyboardButton(text="💰 עדכן הכנסה", callback_data="setincome")],
        [InlineKeyboardButton(text="🔙 חזרה", callback_data="start")],
    ])

def academy_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🪙 מה זה קריפטו?", callback_data="crypto")],
        [InlineKeyboardButton(text="🏦 מה זה CBDC?", callback_data="cbdc")],
        [InlineKeyboardButton(text="🔓 ביזור מול ריכוזיות", callback_data="decentral")],
        [InlineKeyboardButton(text="🌿 סוציוקרטיה", callback_data="socio")],
        [InlineKeyboardButton(text="🧩 NFTזהות", callback_data="academy_nft")],
        [InlineKeyboardButton(text="🏛️ DAO  ארגון מבוזר", callback_data="academy_dao")],
        [InlineKeyboardButton(text="📚 ביזוריות, כלכלה חכמה", callback_data="academy_extended")],
        [InlineKeyboardButton(text="🛡️ טכנולוגיות נגד שחיתות", callback_data="anti")],
        [InlineKeyboardButton(text="🎓 חינוך, כלכלה ורווחה", callback_data="edu")],
        [InlineKeyboardButton(text="❓ שאלות נפוצות", callback_data="faq")],
        [InlineKeyboardButton(text="🤖 שאל שאלה", callback_data="ask")],
        [InlineKeyboardButton(text="🔙 חזרה", callback_data="start")],
    ])

def community_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔗 הקוד שלי להפצה", callback_data="my_ref")],
        [InlineKeyboardButton(text="🏆 לוח מובילים", callback_data="top")],
        [InlineKeyboardButton(text="📊 סטטיסטיקות", callback_data="stats")],
        [InlineKeyboardButton(text="💡 טיפ יומי", callback_data="tip")],
        [InlineKeyboardButton(text="🤖 שאל שאלה", callback_data="ask")],
        [InlineKeyboardButton(text="📝 דיווח תקלה", callback_data="feedback")],
        [InlineKeyboardButton(text="🔙 חזרה", callback_data="start")],
    ])

def presets_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 שכר דירה (2,500)", callback_data="preset_2500_1")],
        [InlineKeyboardButton(text="💰 משכורת (10,000)", callback_data="preset_10000_2")],
        [InlineKeyboardButton(text="🛒 קניות חודשיות (3,000)", callback_data="preset_3000_4")],
        [InlineKeyboardButton(text="🧑💼 פרילנסר (5,000)", callback_data="preset_5000_3")],
        [InlineKeyboardButton(text="🔙 חזרה", callback_data="start")],
    ])

def share_result(amount, tx):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📤 שתף את התוצאה", switch_inline_query=f"חסכתי {amount} בעמלות עם TON!")]
    ])

